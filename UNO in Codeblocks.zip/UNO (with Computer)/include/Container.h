#ifndef CONTAINER_H
#define CONTAINER_H

#include <vector>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>

#include "Card.h"

class Container
{
    public:
        std::vector<Card> vec;
};

#endif // CONTAINER_H
