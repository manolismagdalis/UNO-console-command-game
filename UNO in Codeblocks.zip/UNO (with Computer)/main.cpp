#include <iostream>
#include <vector>   // for using vectors
#include <stdlib.h>
#include <algorithm> // for random shuffling
#include <ctime>        // for time
#include <cstdlib>      // for rand and srand

#include "Card.h"
#include "Container.h"
#include "Deck.h"
#include "Hand.h"
#include "Computer.h"
#include "Player.h"
#include "Game.h"
#include "Necessary_Functions.h"

int main()
{
    srand(time(NULL));
    Game a_game;
    a_game.initiate_game();
    system("pause");
    return 0;
}
